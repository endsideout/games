# Staging Game Links

Use your staging base URL in place of `https://staging-endsideoutgames.netlify.app`.

## Core shareable links

- `https://staging-endsideoutgames.netlify.app/`
- `https://staging-endsideoutgames.netlify.app/3d-wellness`
- `https://staging-endsideoutgames.netlify.app/know-your-health`
- `https://staging-endsideoutgames.netlify.app/know-your-health/set-1`
- `https://staging-endsideoutgames.netlify.app/least-sugar-game`
- `https://staging-endsideoutgames.netlify.app/brain-health-game`
- `https://staging-endsideoutgames.netlify.app/water-glass-game`
- `https://staging-endsideoutgames.netlify.app/finish-race-game`
- `https://staging-endsideoutgames.netlify.app/habit-guard-game`
- `https://staging-endsideoutgames.netlify.app/body-image-game`
- `https://staging-endsideoutgames.netlify.app/financial-literacy`
- `https://staging-endsideoutgames.netlify.app/budgeting-game`

## Spike Lab (static prototype)

Spike Lab is a self-contained static app in `public/spike-lab/`. It does not use the player profile gate or Firebase tracking: no sign-in, and nothing leaves the device.

- `https://staging-endsideoutgames.netlify.app/spike-lab/`
- Preview a date or season: add `?date=2026-11-20` or `?season=winter`

## Optional query-param links (LMS style testing)

- `https://staging-endsideoutgames.netlify.app/least-sugar-game?firstName=Alex&email=alex.tester@example.org&grade=6&teacherName=Ms+Green&schoolName=Staging+Academy`
- `https://staging-endsideoutgames.netlify.app/budgeting-game?firstName=Sam&email=sam.peer@example.org&grade=7&teacherName=Mr+Blake&schoolName=Pilot+School`

## Admin links (protected)

- `https://staging-endsideoutgames.netlify.app/admin/login`
- `https://staging-endsideoutgames.netlify.app/admin`
